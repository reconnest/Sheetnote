# SheetNote — Android-first React + Vite PWA

SheetNote is a mobile-first personal spreadsheet for notes and finances. This build includes an installable Progressive Web App shell so it can be added to an Android home screen and opened in standalone mode.

## Run locally

```bash
npm install
npm run dev -- --host 0.0.0.0
```

Open the Vite network URL on your Android phone while the phone and development computer are on the same Wi-Fi network. Vite development mode is for testing and does not register the production service worker.

## Create and test the installable PWA

```bash
npm install
npm run build
npm run preview -- --host 0.0.0.0
```

Open the preview URL on Android Chrome using the computer's LAN IP and the preview port (usually `4173`). The phone and computer must be on the same Wi-Fi network. For reliable installation and service-worker support, use HTTPS on a hosted site; `localhost` is treated as secure only on the device where it runs.

In Android Chrome:

1. Open the hosted HTTPS SheetNote URL.
2. Wait for the page to finish loading.
3. Tap the **Install** control if Chrome exposes the install prompt, or open Chrome's ⋮ menu and choose **Install app** / **Add to Home screen**.
4. Launch SheetNote from the home screen.
5. Test editing, formulas, sheet tabs, CSV import/export, JSON backup/restore, offline launch and data retention after closing/reopening.

## PWA files

- `public/manifest.webmanifest` — app identity, standalone display, theme and icons.
- `public/sw.js` — app-shell and same-origin asset caching for offline reopening after the first successful online visit.
- `public/icons/` — Android install icons (192px, 512px and maskable 512px).

The service worker is registered only in production builds. The browser must load the app once while online before offline caching is available. Third-party fonts are not guaranteed offline.

## Data storage

Workbook data is stored locally in IndexedDB, with localStorage fallback. Data remains on the device/browser profile and is not synchronized to other devices. Export a JSON backup regularly. Clearing Chrome site data can remove the local workbook.

## Current migration scope

This is an Android-first PWA foundation, not yet full parity with the original HTML application. Existing gaps are documented below and in the source migration notes: advanced formulas, table sorting/filtering, conditional formatting UI, charts, dropdown validation, checkbox cells, format painter, column resizing, multi-range selection, complete system clipboard support, and formula-reference rewriting after row/column changes.

The original `personal_excel.html` is retained as the functional reference. Do not delete it until feature parity and migration tests are complete.
