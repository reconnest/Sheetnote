SheetNote — Personal Excel for Notes & Finances
=================================================

How to use:
1. Extract this zip archive.
2. Open personal_excel.html in any modern web browser (Chrome, Edge, Safari, Firefox).
3. Your sheets and data are automatically saved in your browser's local storage.
4. Use the "Backup" button in the top bar to export a .json backup of your entire workbook anytime, and "Restore" to reload it.
